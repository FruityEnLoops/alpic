int countLines(FILE * filePointer);
int checkStates(FILE * filePointer);
int checkFile(FILE * filePointer);