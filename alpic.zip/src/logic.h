int containsString(char c, char* s);
int contains(char c, char** state);
int checkWord(FILE * filePointer, logic l, char * word);